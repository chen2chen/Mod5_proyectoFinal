package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import conexion.GeneraConexion;
import modelo.Horoscopo;

public class HoroscopoDAO {
	
	public List<Horoscopo> obtenerHoroscopo() throws SQLException {
        List<Horoscopo> listaHoroscopo = new ArrayList<>();
        String sql = "SELECT ANIMAL, FECHA_INICIO, FECHA_FIN FROM HOROSCOPO";

        try (Connection conn = GeneraConexion.getConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String animal = rs.getString("animal");
                LocalDate fechaInicio = rs.getDate("fecha_inicio").toLocalDate();
                LocalDate fechaFin = rs.getDate("fecha_fin").toLocalDate();

                Horoscopo horoscopo = new Horoscopo(animal, fechaInicio, fechaFin);
                listaHoroscopo.add(horoscopo);
            }
        }
        return listaHoroscopo;
    }

}
