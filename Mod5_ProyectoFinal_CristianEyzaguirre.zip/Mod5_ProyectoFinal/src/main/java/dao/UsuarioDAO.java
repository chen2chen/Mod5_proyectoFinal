package dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;


import conexion.GeneraConexion;


import modelo.Usuario;


public class UsuarioDAO {

	public List<Usuario> listar() throws SQLException {

		List<Usuario> usuarios = new ArrayList<>();
		String sql = "select * from usuarios order by 1";

		try (Connection conn = GeneraConexion.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {
			ResultSet rs = stmt.executeQuery();

			// iterar los resultados
			while (rs.next()) {
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				String username = rs.getString("username");
				String mail = rs.getString("email");
				java.sql.Date sqlDate = rs.getDate("fecha_nacimiento");
				// Formatea la fecha como String
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				String fechaNac = sqlDate != null ? dateFormat.format(sqlDate) : null;

				String password = rs.getString("password");

				Usuario u = new Usuario(id, nombre, username, mail, fechaNac, password, password);
				usuarios.add(u);

			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // Re-lanzar la excepción para que el método llamante pueda manejarla
		}

		return usuarios;

	}

	public void crearUsuario(Usuario u) throws SQLException, ClassNotFoundException {

		String sql = "INSERT INTO USUARIOS (NOMBRE, USERNAME, EMAIL, FECHA_NACIMIENTO, PASSWORD) VALUES (?,?,?,?,?)";

		try (Connection conn = GeneraConexion.getConexion();
		     PreparedStatement stmt = conn.prepareStatement(sql)) {

			  stmt.setString(1, u.getNombre());
		        stmt.setString(2, u.getUsername());
		        stmt.setString(3, u.getMail());
		        stmt.setDate(4, java.sql.Date.valueOf(u.getFechaNacimiento())); // LocalDate a SQL Date
		        stmt.setString(5, u.getPassword());

			stmt.executeUpdate(); // Ejecutar la consulta
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // Re-lanzar la excepción para que el método llamante pueda manejarla
		}
	}

	// definir método buscar para la sesion
	public Usuario BuscarSesion(String username, String password) {

		Usuario usuario = null;
		
		String sql = "SELECT USERNAME, PASSWORD, NOMBRE, FECHA_NACIMIENTO FROM USUARIOS WHERE USERNAME= ? AND PASSWORD= ?";
		
		try {

			// conectar con BD
			Connection conn = GeneraConexion.getConexion();
			// ejecutar sentencia
			PreparedStatement ps = conn.prepareStatement(sql);

			// parametros de consulta
			ps.setString(1, username);
			ps.setString(2, password);

			try (ResultSet rs = ps.executeQuery()) {

				// llenar arraylist con resultados de consulta
				while (rs.next()) {
					// crea el usuario

					String nombre = rs.getString("NOMBRE");
					String user = rs.getString("USERNAME");
					String pass = rs.getString("PASSWORD");
					//String fechaNacimiento = rs.getString("FECHA_NACIMIENTO"); // Recuperar la fecha de nacimiento
					// Recuperar la fecha y convertirla a LocalDate
				    Date fechaNacimientoSQL = rs.getDate("FECHA_NACIMIENTO");
				    String fechaNacimiento = fechaNacimientoSQL.toString(); // Convertir a formato yyyy-MM-dd

					// System.out.println("Resultado de la consulta - Username: " + user + ",
					// Nombre: " + nombre);
					usuario = new Usuario(user, pass, nombre);
					usuario.setFechaNacimiento(fechaNacimiento);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (usuario != null) {
			// System.out.println("Usuario no encontrado o credenciales incorrectas.");
			System.out.println("Usuario encontrado: " + usuario.getNombre()+" (usuarioDao)");
	        System.out.println("Fecha de nacimiento: " + usuario.getFechaNacimiento()+" (usuarioDao)");
	    
		}else {
	        System.out.println("Usuario o contraseña incorrectos(usuarioDao).");
	    }
		return usuario;
	}

	public void editarUsuario(Usuario u) throws SQLException {

		String sql = "UPDATE USUARIOS SET NOMBRE=?, USERNAME=?, EMAIL=?, FECHA_NACIMIENTO=?, PASSWORD=? WHERE ID=?";

		try (Connection conn = GeneraConexion.getConexion(); PreparedStatement stmt = conn.prepareStatement(sql)) {

			// Establecer los parámetros
			stmt.setString(1, u.getNombre());
			stmt.setString(2, u.getUsername());
			stmt.setString(3, u.getMail());
			stmt.setDate(4, java.sql.Date.valueOf(u.getFechaNacimiento())); // Asegúrate de manejar correctamente el
																			// tipo de fecha
			stmt.setString(5, u.getPassword());
			stmt.setInt(6, u.getId());

			// Ejecutar la actualización
			int filasActualizadas = stmt.executeUpdate();
			if (filasActualizadas > 0) {
				System.out.println("Usuario actualizado correctamente.");
			} else {
				System.out.println("No se encontró el usuario con el ID especificado.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e; // Re-lanzar la excepción para que el método llamante pueda manejarla
		}

	}

	// definir método buscar para lista
	public Usuario BuscarLista(int idUsuario) {

		Usuario usuario = null;

		String sql = "select * from usuarios where id= ?";

		try {

			// conectar con BD
			Connection conn = GeneraConexion.getConexion();
			// ejecutar sentencia
			PreparedStatement ps = conn.prepareStatement(sql);

			// parametros de consulta
			ps.setInt(1, idUsuario);

			try (ResultSet rs = ps.executeQuery()) {

				// llenar arraylist con resultados de consulta
				while (rs.next()) {
					// crea el usuario

					int id = rs.getInt("ID");
					String nombre = rs.getString("NOMBRE");
					String user = rs.getString("USERNAME");
					String mail = rs.getString("EMAIL");
					java.sql.Date sqlDate = rs.getDate("fecha_nacimiento");
					// Formatea la fecha como String
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					String fechaNac = sqlDate != null ? dateFormat.format(sqlDate) : null;
					// LocalDate fechaNac = rs.getDate("fecha_nacimiento").toLocalDate(); //
					// Convertir a LocalDate
					String pass = rs.getString("PASSWORD");

					// System.out.println("Resultado de la consulta - Username: " + user + ",
					// Nombre: " + nombre);
					usuario = new Usuario(id, nombre, user, mail, fechaNac, pass, pass);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (usuario == null) {
			// System.out.println("Usuario no encontrado o credenciales incorrectas.");
		}
		return usuario;
	}

	public void eliminar(int id) throws SQLException, ClassNotFoundException {
		 String sql = "DELETE FROM USUARIOS WHERE id = ?";

		    try (Connection conn = GeneraConexion.getConexion();
		         PreparedStatement stmt = conn.prepareStatement(sql)) {
		        
		        // Asignar el valor al marcador de posición
		        stmt.setInt(1, id);

		        // Ejecutar la consulta
		        int rowsAffected = stmt.executeUpdate();

		        if (rowsAffected == 0) {
		            System.out.println("No se encontró un usuario con el ID especificado: " + id);
		        } else {
		            System.out.println("Usuario con ID " + id + " eliminado correctamente.");
		        }

		    } catch (SQLException e) {
		        e.printStackTrace();
		        throw e; // Re-lanzar la excepción para que el método llamante pueda manejarla
		    }
	}
		
	public List<Usuario> filtroNombre(String nombre) 
		    		throws SQLException {
		    	   
				
		    	List<Usuario> usuarios = new ArrayList<>();
				String sql = "SELECT * FROM USUARIOS WHERE NOMBRE LIKE ?";

				 try (Connection conn = GeneraConexion.getConexion();
				         PreparedStatement stmt = conn.prepareStatement(sql)) {

				        // Agregar el valor con el patrón de búsqueda
				        stmt.setString(1, "%" + nombre + "%");

				        try (ResultSet rs = stmt.executeQuery()) {
				            while (rs.next()) {
				               int id = rs.getInt("ID");
				                String nombreUsuario = rs.getString("NOMBRE");
				                String username = rs.getString("USERNAME");
				                String email = rs.getString("EMAIL");
				                String fechaNacimiento = rs.getString("FECHA_NACIMIENTO");
				                String password = rs.getString("PASSWORD");
				                
				                // Crear y agregar el usuario a la lista
				                Usuario usuario = new Usuario(id, nombreUsuario, username, email, fechaNacimiento, password);
				                usuarios.add(usuario);
				            }
				        }
				    }
				    return usuarios;
		  
		    
		}
		    
		    
	}
	
	
