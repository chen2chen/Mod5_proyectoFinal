package modelo;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import dao.HoroscopoDAO;

public class HoroscopoServicio {
	public void asignarHoroscopo(Usuario usuario) throws SQLException {
        // Convertir la fecha de nacimiento (que está en formato String) a LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate fechaNacimiento = LocalDate.parse(usuario.getFechaNacimiento(), formatter);

        // Obtener la lista de horóscopos (esto normalmente se haría con un DAO o servicio)
        List<Horoscopo> listaHoroscopo = new HoroscopoDAO().obtenerHoroscopo();

        // Inicializar el horóscopo a null por si no se encuentra ningún signo
        Horoscopo horoscopo = null;

        // Buscar el signo correspondiente
        for (Horoscopo temp : listaHoroscopo) {
            if (fechaNacimiento.isAfter(temp.getFechaInicio()) && fechaNacimiento.isBefore(temp.getFechaFin())) {
                horoscopo = temp;
                
                break;
            } else if (fechaNacimiento.isEqual(temp.getFechaInicio()) || fechaNacimiento.isEqual(temp.getFechaFin())) {
                horoscopo = temp;
                
                System.out.println("Probando con signo: " + temp.getAnimal());
                System.out.println("Fecha inicio: " + temp.getFechaInicio() + ", Fecha fin: " + temp.getFechaFin());

                break;
            }
        }

        // Si se encontró un horóscopo, asignarlo al usuario
        if (horoscopo != null) {
            usuario.setAnimal(horoscopo.getAnimal());
        } else {
            // Si no se encontró, manejar el caso de error (opcional)
            throw new IllegalArgumentException("No se encontró un horóscopo para la fecha proporcionada.");
        }
    }

}
