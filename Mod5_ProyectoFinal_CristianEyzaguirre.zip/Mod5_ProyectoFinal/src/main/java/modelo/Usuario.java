package modelo;

import java.time.LocalDate;

public class Usuario {
	private int id;
	private String nombre, username, mail;
	private String fechaNacimiento;
	private String password, animal;
	
	public Usuario(int id, String nombre, String username, String mail, String fechaNacimiento, 
			String password, String animal) {
		this.id = id;
		this.nombre = nombre;
		this.username = username;
		this.mail = mail;
		this.fechaNacimiento = fechaNacimiento;
		this.password = password;
		this.animal = animal;
	}
	public Usuario(int id, String nombre, String username, String mail, String fechaNacimiento, 
			String password) {
		this.id = id;
		this.nombre = nombre;
		this.username = username;
		this.mail = mail;
		this.fechaNacimiento = fechaNacimiento;
		this.password = password;
	}
	
	public Usuario( String nombre, String username, String mail, String fechaNacimiento, 
			String password) {
		this.nombre = nombre;
		this.username = username;
		this.mail = mail;
		this.fechaNacimiento = fechaNacimiento;
		this.password = password;
		
	}
	public Usuario(String usernameus, String password, String nombre) {
		this.nombre = nombre;
		this.username = username;
		this.password = password;
	}
	public Usuario(String nombre, String fechaNacimiento) {
		 this.nombre = nombre;
	     this.fechaNacimiento = fechaNacimiento;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAnimal() {
		return animal;
	}
	public void setAnimal(String animal) {
		this.animal = animal;
	}
	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nombre=" + nombre + ", username=" + username + ", mail=" + mail
				+ ", fechaNacimiento=" + fechaNacimiento + ", password=" + password + ", animal=" + animal + "]";
	}
	
	
	

}
