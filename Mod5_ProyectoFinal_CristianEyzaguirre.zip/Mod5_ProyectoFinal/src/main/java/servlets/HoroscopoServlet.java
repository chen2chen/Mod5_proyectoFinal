package servlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import modelo.HoroscopoServicio;
import modelo.Usuario;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Servlet implementation class HoroscopoServicio
 */
@WebServlet("/HoroscopoServlet")
public class HoroscopoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HoroscopoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// Obtener el usuario de la sesión
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null) {
            response.sendRedirect("logear.jsp"); // Si no hay sesión activa, redirigir al login
            return;
        }
        if (usuario.getFechaNacimiento() == null || usuario.getFechaNacimiento().isEmpty()) {
            System.out.println("Error: La fecha de nacimiento no está definida en el objeto Usuario.");
            response.getWriter().println("Error: No se pudo cargar la fecha de nacimiento del usuario.");
            return;
        }


        // Asignar el horóscopo al usuario
        HoroscopoServicio horoscopoServicio = new HoroscopoServicio();
        try {
            horoscopoServicio.asignarHoroscopo(usuario);
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error al asignar horóscopo: " + e.getMessage());
            return; // Terminar la ejecución si hay error
        }

        // Pasar el horóscopo a la vista
        request.setAttribute("horoscopo", usuario.getAnimal());

        // Redirigir a la página que muestra el horóscopo
        RequestDispatcher dispatcher = request.getRequestDispatcher("horoscopo.jsp");
        dispatcher.forward(request, response);
        
        System.out.println("Fecha de nacimiento del usuario: " + usuario.getFechaNacimiento());
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		 // Obtener la fecha de nacimiento y nombre del formulario
        String nombre = request.getParameter("nombre");
        String fechaNacimiento = request.getParameter("fechaNacimiento");

        // Verificar que los parámetros no estén vacíos
        if (nombre == null || nombre.trim().isEmpty() || fechaNacimiento == null || fechaNacimiento.trim().isEmpty()) {
            response.getWriter().println("Error: El nombre o la fecha de nacimiento no pueden estar vacíos.");
            return;
        }

        // Crear el objeto Usuario con la fecha de nacimiento
        Usuario usuario = new Usuario(nombre, fechaNacimiento);

        try {
            // Crear el servicio y asignar el horóscopo
            HoroscopoServicio servicio = new HoroscopoServicio();
            servicio.asignarHoroscopo(usuario);

            // Establecer el animal (signo) del horóscopo en la respuesta
            request.setAttribute("horoscopo", usuario.getAnimal());

            // Redirigir o reenviar la respuesta a la página de resultados
            RequestDispatcher dispatcher = request.getRequestDispatcher("Horoscopo.jsp");
            dispatcher.forward(request, response);

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("Error al procesar el horóscopo: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}