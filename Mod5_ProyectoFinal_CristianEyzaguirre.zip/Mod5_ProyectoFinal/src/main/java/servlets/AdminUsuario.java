package servlets;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import modelo.Usuario;

import java.io.IOException;
import java.sql.SQLException;

import java.time.format.DateTimeParseException;
import java.util.List;


import dao.UsuarioDAO;


/**
 * Servlet implementation class RegistrarUsuario
 */
@WebServlet("/AdminUsuario")
public class AdminUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UsuarioDAO usuarioDAO = new UsuarioDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//recuperar listado de empleados
				String opcion = request.getParameter("opcion");

				if (opcion == null) {
					opcion = "agregar";
				}

				switch (opcion) {
				case "agregar":
					agregarUsuario(response);
					break;
				case "listar":
		            try {
		                listarUsuario(request, response);
		            } catch (SQLException e) {
		                e.printStackTrace();  // Manejo de la excepción SQLException
		            }
		            break;

				case "editar":
					editarUsuario(request, response);
					break;

				case "eliminar":
					eliminarUsuario(request, response);
					break;
				}
	
	}

	

private void eliminarUsuario(HttpServletRequest request, HttpServletResponse response)
		throws IOException {
	
	int id = Integer.parseInt(request.getParameter("id"));

	try {
		usuarioDAO.eliminar(id);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	} catch (SQLException e) {
		e.printStackTrace();
	}

	// Redirigir a la lista de personas
	// Guardar mensaje en la sesión
    HttpSession session = request.getSession();
    session.setAttribute("msjBorrar", "Usuario Eliminado del Registro...");
    
    	response.sendRedirect("AdminUsuario?opcion=listar");
	}

private void editarUsuario(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		

	int id = Integer.parseInt(request.getParameter("id"));
	Usuario u = usuarioDAO.BuscarLista(id);
	
	request.setAttribute("usuario", u);
	
	
	RequestDispatcher dispatcher = request.getRequestDispatcher("editar.jsp");
	dispatcher.forward(request, response);
	
	
	}

private void listarUsuario(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException, SQLException {

	
	List<Usuario> listaUsuarios = usuarioDAO.listar();
	request.setAttribute("usuarios", listaUsuarios);
	
	RequestDispatcher dispatcher = request.getRequestDispatcher("listar.jsp");
	dispatcher.forward(request, response);
	
	}

private void agregarUsuario(HttpServletResponse response) throws IOException {
		
		response.sendRedirect("registrarse.jsp");
		
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
protected void doPost(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {

    String accionf = request.getParameter("filtrar");
    if ("filtroNombre".equals(accionf)) {
        filtrarUsuarios(request, response);
        return;
    }

    // Identificar si viene de un agregar o de un editar
    String accion = request.getParameter("accion");

    // Recuperar valores del formulario con validación
    int id = 0;
    try {
        String idUsuario = request.getParameter("idUsuario");
        if (idUsuario != null && !idUsuario.isEmpty()) {
            id = Integer.parseInt(idUsuario);
        }
    } catch (NumberFormatException e) {
        request.setAttribute("msjError", "ID de usuario inválido.");
        request.getRequestDispatcher("registrarse.jsp").forward(request, response);
        return;
    }

    String nombre = request.getParameter("nombre");
    String username = request.getParameter("username");
    String mail = request.getParameter("mail");
    String fechaNac = request.getParameter("fechaNacimiento");
    String password = request.getParameter("pass");

    // Validar campos obligatorios
    if (nombre == null || username == null || mail == null || fechaNac == null || password == null ||
        nombre.isEmpty() || username.isEmpty() || mail.isEmpty() || fechaNac.isEmpty() || password.isEmpty()) {
        request.setAttribute("msjError", "Todos los campos son obligatorios.");
        request.getRequestDispatcher("registrarse.jsp").forward(request, response);
        return;
    }

    try {
        // Crear objeto Usuario
        Usuario u = new Usuario(id, nombre, username, mail, fechaNac, password, password);

        if ("registrar".equals(accion)) {
            // Método que agrega usuario
            usuarioDAO.crearUsuario(u);
            response.sendRedirect("IniciaSesion");
            return;

        } else if ("editar".equals(accion)) {
            // Método que edita usuario
            usuarioDAO.editarUsuario(u);
            
            // Guardar el mensaje en la sesión
            HttpSession session = request.getSession();
            session.setAttribute("msjModExito", "Datos Modificados Exitosamente....");
            
            response.sendRedirect("AdminUsuario?opcion=listar");
            return;

        } else {
            // Acción no reconocida
            request.setAttribute("msjError", "Acción no válida.");
            request.getRequestDispatcher("formulario.jsp").forward(request, response);
        }

    } catch (DateTimeParseException e) {
        // Manejar errores de formato de fecha
        e.printStackTrace();
       // request.setAttribute("msjError", "Formato de fecha inválido. Use AAAA-MM-DD.");
       // request.getRequestDispatcher("formulario.jsp").forward(request, response);

    } catch (ClassNotFoundException | SQLException e) {
        // Manejar errores generales
        e.printStackTrace();
        //request.setAttribute("msjError", "Error al procesar la operación. Intente más tarde.");
        //request.getRequestDispatcher("formulario.jsp").forward(request, response);
    }
}

	
	private void filtrarUsuarios(HttpServletRequest request, HttpServletResponse response) 
	        throws ServletException, IOException {
	    String nombre = request.getParameter("nombre");

	    try {
	        // Llama al método en el DAO para obtener los usuarios filtrados
	        List<Usuario> usuariosFiltrados = usuarioDAO.filtroNombre(nombre);

	        // Agregar los resultados como atributo
	        request.setAttribute("usuarios", usuariosFiltrados);

	        // Redirige a la vista con los resultados
	        RequestDispatcher dispatcher = request.getRequestDispatcher("listar.jsp");
	        dispatcher.forward(request, response);

	    } catch (SQLException e) {
	        e.printStackTrace();
	        request.setAttribute("msjError", "Error al filtrar usuarios. Intente nuevamente.");
	        request.getRequestDispatcher("error.jsp").forward(request, response);
	    }
	}
	
	
	
	}
