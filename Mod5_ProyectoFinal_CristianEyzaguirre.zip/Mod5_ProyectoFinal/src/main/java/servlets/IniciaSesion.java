package servlets;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import modelo.Usuario;

import java.io.IOException;

import dao.UsuarioDAO;

/**
 * Servlet implementation class IniciaSesion
 */
@WebServlet("/IniciaSesion")
public class IniciaSesion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UsuarioDAO usuarioDAO = new UsuarioDAO();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IniciaSesion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		//request.getRequestDispatcher("logear.jsp").forward(request, response);
		request.setAttribute("msjExito", "Registro completado exitosamente. ¡Ya puedes iniciar sesión!");
		request.getRequestDispatcher("logear.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// Recuperar los valores del formulario
        String user = request.getParameter("user").trim();
        String pass = request.getParameter("pass").trim();

        // Validar entrada
        if (user == null || user.isEmpty() || pass == null || pass.isEmpty()) {
            request.setAttribute("msjError", "Debe ingresar un usuario y una contraseña.");
            request.getRequestDispatcher("logear.jsp").forward(request, response);
            return;
        }

        // Verificar credenciales
        Usuario u = usuarioDAO.BuscarSesion(user, pass);

        if (u != null) {
            // Crear la sesión y guardar el objeto Usuario
            HttpSession session = request.getSession(true);
            session.setAttribute("usuario", u);

            // Redirigir a la página de bienvenida
            response.sendRedirect("bienvenida.jsp");
        } else {
            // Usuario o contraseña incorrecta
            request.setAttribute("msjError", "Usuario o contraseña no válida. Si no tienes cuenta, regístrate.");
            request.getRequestDispatcher("logear.jsp").forward(request, response);
        }
    }
}
